package Extends2modifier;

public class Test {
    public static void main(String[] args) {
        Father f = new Father();
        f.method();
        f.protectedmethod();
        f.publicmethod();
        //f.privatemethod();
    }
}
