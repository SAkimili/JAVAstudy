package Extends2modifier;
//成员变量一般私有（封装），方法大概率公开
public class Father {
    //1.private:只能当前类中访问
    private void privatemethod(){
        System.out.println("privatemethod");
    }
    //2.缺省:只能当前类和同一个包下的类访问
    void method(){//缺省
        System.out.println("defmethod");
    }
    //3.protected:只能当前类、同一个包下的类、子孙类访问
    protected void protectedmethod(){
        System.out.println("protmethod");
    }
    //4.public:任何类中都能访问
    public void publicmethod(){
        System.out.println("pubmethod");
    }

    public static void main(String[] args) {
        Father f = new Father();
        f.method();
        f.protectedmethod();
        f.publicmethod();
        f.privatemethod();
    }
}
