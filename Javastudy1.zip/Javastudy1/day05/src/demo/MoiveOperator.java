package demo;

import java.util.Scanner;

//电影操作类
public class MoiveOperator {
    private Movie[] movies;//记住一个电影对象的数组
//因为movis写了private，所有私有了，就要通过构造器获取
    public MoiveOperator(Movie[] movies) {//有参构造器
        this.movies = movies;
    }
//打印全部电影

    public void printAllmovies() {
        System.out.println("=====全部电影如下======");
        for (int i = 0; i < movies.length; i++) {
            Movie m=movies[i];
            System.out.println(m.getId()+"\t"+m.getName()+"\t"+m.getPrice());
        }
    }
//按编号查询电影
    public void printByID() {
        System.out.println("请输入要查询的编号：");
        Scanner scanner = new Scanner(System.in);
        //遍历每个电影编号
        int id = scanner.nextInt();
        for (int i = 0; i < movies.length; i++) {
            //拿到当前遍历到的电影对象
            Movie m=movies[i];
            //判断当前遍历到的电影编号是否和用户输入的编号一致，是就打印信息并立即结束循环
            if (id == m.getId()) {
                System.out.println(m.getId()+"\t"+m.getName()+"\t"+m.getPrice());

                return;
            }
        }
        System.out.println("没有找到");
    }
}
