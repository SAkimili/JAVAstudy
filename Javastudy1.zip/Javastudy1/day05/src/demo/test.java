package demo;

public class test {
    //目标：完成一个小项目
    //1.设计电影类Movie，以便创建电影对象，封装电影数据
    //2.封装系统中的全部电影数据（没学数据库就自己造数据）
    public static void main(String[] args) {
        Movie[] movies=new Movie[7];
        //创建电影对象，movie引用类型
        //和int[] arr=new int[9];一样
        //movies=[null,null,null,null,null,null]
        //        0     1     2    3   4   5
        movies[0]=new Movie("机动战士高达Gquuuuuux",1,30.5);
        movies[1]=new Movie("机动战士高达 THE ORIGIN I：苍瞳的卡斯巴尔",2,35.5);
        movies[2]=new Movie("机动战士高达 THE ORIGIN II：悲哀的阿尔黛西亚",3,35.5);
        movies[3]=new Movie("机动战士高达 THE ORIGIN VI：红色彗星的诞生",4,50.5);
        movies[4]=new Movie("赛马娘 芦毛灰姑娘",5,40.5);
        movies[5]=new Movie("2025明日方舟音律联觉：集成映射",6,100.5);
        movies[6]=new Movie("明日方舟：焰烬曙明",7,40.5);
        //3.创建电影操作对象出来，专门负责电影数据的业务操作
        MoiveOperator operator = new MoiveOperator(movies);
        operator.printAllmovies();//Alt键+回车+回车enter
        operator.printByID();



}
}
