package Extends1Demo;

public class test {
    //目标：认识继承和继承的好处
    //子类可以继承父类的非私有成员。
    //子类对象其实是由子类和父类多张设计图共同创建出来的对象。
    public static void main(String[] args) {
        newpeople np = new newpeople();
        np.setName("塞拉");
        np.setSex('女');
        np.setSkill("发黄金");
        System.out.println("姓名:"+np.getName());
        System.out.println("性别："+np.getSex());
        System.out.println("技能："+np.getSkill());
    }
}
