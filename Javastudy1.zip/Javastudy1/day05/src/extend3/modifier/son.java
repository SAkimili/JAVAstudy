package extend3.modifier;

import Extends2modifier.Father;

public class son extends Father {
    public void show() {
        // privatemethod();
        //method();
        protectedmethod();
        publicmethod();


    }
}
