package extend3.modifier;

import Extends2modifier.Father;

public class demo {
    public static void main(String[] args) {
        Father f = new Father();
        f.publicmethod();
        //f.protectedmethod();
       // f.method();
       // f.privatemethod();
    }
}
