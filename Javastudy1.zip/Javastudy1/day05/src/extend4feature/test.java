package extend4feature;

public class test {
    public static void main(String[] args) {
        //
    }
}
//1.java的类只能是单继承的，不支持多继承，支持多层继承
//2.一个类要么直接继承  Object,要么默认继承Object，要么间接继承Object
class  A {

}
class B extends A{

}
class C extends B{

}
class Fu{
    String  name="FU的name";
    public void run(){
        System.out.println("Fu的run");
    }
}
class Zi extends Fu{
    String name="Zi的name";
    public void show(){
       String  name="show的name";
       System.out.println(name);//show的name
        System.out.println(this.name);//Zi的name
        System.out.println(super.name);//Fu的name
        run();//子类的
        super.run();//父类的
    }
    public void run(){
        System.out.println("Zi的run");
    }
}
