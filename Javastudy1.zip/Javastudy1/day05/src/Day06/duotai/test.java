package Day06.duotai;

public class test {
    public static void main(String[] args) {
        //目标：认识多态
        //1.对象多态，行为多态
        animal a1=new wolf();
        a1.run();//编译看左边，运行看右边（animal等号的左右）
        System.out.println(a1.name);
        animal a2=new wugui();//成员变量：编译看左边，运行也看左边
        a2.run();//编译看左边，运行看右边
        System.out.println(a2.name);//成员变量：编译看左边，运行也看左边

    }
}
