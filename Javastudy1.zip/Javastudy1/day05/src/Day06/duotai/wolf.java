package Day06.duotai;

public class wolf extends animal{
    String name="狼";
    @Override
    public void run() {
        System.out.println("狼跑-----");
    }
}
