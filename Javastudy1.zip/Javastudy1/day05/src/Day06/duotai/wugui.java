package Day06.duotai;

public class wugui extends animal {
    String name="乌龟";
    @Override
    public void run() {
        System.out.println("乌龟在跑---");
    }
}
