package Day06.duotai3;

public class animal {
String name="动物";
    public void run(){
        System.out.println("动物在跑~~~");
    }
}
