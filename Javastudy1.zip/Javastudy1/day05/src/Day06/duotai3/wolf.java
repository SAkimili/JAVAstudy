package Day06.duotai3;

public class wolf extends animal {
    String name="狼";
    @Override
    public void run() {
        System.out.println("狼跑-----");
    }
    public void eatsheep(){
        System.out.println("狼吃羊");
    }
}
