package Day06.duotai3;

public class test {
    public static void main(String[] args) {
        //目标：认识多态
        //1.对象多态，行为多态
        //1.多态的好处1：右边对象是解耦合的（wolf可以直接改成wugui）
        animal a1=new wolf();
        a1.run();
       // a1.eatsheep();
        //多态的缺陷
        //报错，多态下不能调用子类独有的功能
        //可以进行强制类型的转换:可以解决多态下调用子类独有功能
        wolf w3= (wolf) a1;
        ((wolf) a1).eatsheep();
        //有继承关系就可以强制转换，编译阶段不会报错
        //但是运行阶段会报错
        //wugui w4= (wolf) a1;
        if (a1 instanceof wolf){
            wolf w4= (wolf) a1;
            w4.eatsheep();
        } else if (a1 instanceof wugui) {
            wugui w5= (wugui) a1;
            w5.shrinkhead();

        }
        System.out.println("-------------------------");

        wolf w1=new wolf();
        go(w1);
        wugui w2=new wugui();
        go(w2);
    }
    //宠物游戏：所有动物都可以送给这个方法跑步
    //2.多态好处2：父类类型的变量作为参数，可以接收一个子类对象
    public static void go(animal w) {
        System.out.println("go---------");
        w.run();
        //Java建议强制转换前，应该判断对象的真实类型，在进行强制类型转换
        if(w instanceof wolf){
            wolf ww=(wolf)w;
            ww.eatsheep();
        } else if (w instanceof wugui) {
            wugui ww=(wugui)w;
            ww.shrinkhead();

        }
    }
}
