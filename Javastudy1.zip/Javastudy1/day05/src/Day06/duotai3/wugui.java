package Day06.duotai3;

public class wugui extends animal {
    String name="乌龟";
    @Override
    public void run() {
        System.out.println("乌龟在跑---");
    }
    public void shrinkhead()
    {
        System.out.println("乌龟缩头");
    }
}
