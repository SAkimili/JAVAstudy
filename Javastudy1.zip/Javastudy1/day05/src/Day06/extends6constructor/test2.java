package Day06.extends6constructor;

public class test2 {
    public static void main(String[] args) {
        //目标：子类构造器调用父类构造器的应用场景
     consultant c1 = new consultant("张三",20,"java");
     System.out.println(c1.getName());
     System.out.println(c1.getAge());
     System.out.println(c1.getSkill());


    }
}
