package Day06.extends6constructor;

public class consultant extends people  {
   private   String skill;
    public consultant(String name, int age, String skill) {
        //子类构造器调用父类构造器的应用场景
        //可以把子类继承自父类这部分的数据也完成初始化赋值
        super(name , age);
        this.skill=skill;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }
}
