package Day06.extends6constructor;

public class student {
    private String name;
   private int age;
   private String school;
public student() {
    }

    public student(String name, int age) {
        //this.name = name;
       // this.age = age;
        //this.school ="清华大学";
        //this调用兄弟构造器
        //注意：super（...）this（...）必须写在构造器的第一行，而且两者不能同时出现
        this(name, age,"清华大学");
    }

    public student(String name, int age, String school) {
        super();//必须在第一行
        this.name = name;
        this.age = age;
        this.school = school;


    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    @Override
    public String toString() {
        return "student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", school='" + school + '\'' +
                '}';
    }
}
