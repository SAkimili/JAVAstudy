package Day06.extends6constructor;

import javabean.student;

public class test {
    public static void main(String[] args) {
        //目标：认识子类构造器的特点，再看引用场景。
        //子类构造器必须先调用父类的构造器，zai执行自己的构造器
        zi z = new zi();
    }
}
class zi extends fu{
    public zi(){
       //super();//默认存在，写不写都有
         super(233);//指定调用父类有参构造器
        System.out.println("子类无参构造");
    }
}
class fu{
     private  fu(){
        System.out.println("父类无参构造");
    }
    public fu(int a){
        System.out.println("父类有参构造");
    }
}
