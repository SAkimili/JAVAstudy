package Day06.extends6constructor;

public class test3 {
    public static void main(String[] args) {
        //目标：理解this（...）调用兄弟构造器
        //创建对象，存储一个学生的数据
        student s1 = new student("小明", 18, "清华大学");
        System.out.println(s1);
        student s2=new student("小红果",19,"山东大学");
        System.out.println(s2);
        student s3=new student("小王",20);
        System.out.println(s3);
    }
}
