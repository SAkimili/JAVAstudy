package Day06.duotai2;

public class test {
    public static void main(String[] args) {
        //目标：认识多态
        //1.对象多态，行为多态
        //1.多态的好处1：右边对象是解耦合的（wolf可以直接改成wugui）
        animal a1=new wolf();
        a1.run();
       // a1.eatsheep();
        //多态的缺陷
        //报错，多态下不能调用子类独有的功能

        wolf  w1=new wolf();
        go(w1);
        wugui w2=new wugui();
        go(w2);
    }
    //宠物游戏：所有动物都可以送给这个方法跑步
    //2.多态好处2：父类类型的变量作为参数，可以接收一个子类对象
    public static void go(animal w) {
        System.out.println("go---------");
        w.run();
    }
}
