package Day06.extends5override;

public class test {
    public static void main(String[] args) {
        //目标：认识方法重写，在搞清楚场景
        Dog d = new Dog();
        d.eat();
    }
}

class Dog extends Animal{
    //方法重写：方法名称，形参列表必须一样，这个方法就是方法重写
    //重写的声明：生命不变，重新实现
    @Override//方法重写的校验注释（标志）：要求方法名称和形参列表必须与被重写方法一致，
    //否则报错！更安全，可读性好，更优雅
    public void eat(){
        System.out.println("吃狗粮");
    }
}
class Animal{
    public void eat(){
        System.out.println("吃冲冲");
    }
}
