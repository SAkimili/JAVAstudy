package Day06.extends5override;

import staticDemo.Student;

public class test2 {
    public static void main(String[] args) {
     //目标：方法重写的常见应用场景：子类重写object的toString方法,以便返回对象的内容
        student s=new student("拉拉",16);
        //System.out.println(s.toString());//Day06.extends5override.student@2f4d3709 所谓的地址
        System.out.println(s);
        //注意1：直接输出对象，默认会调用object的tostring方法(可以忽略不屑调用tostring的代码)，返回对象的地址信息
        //注意2：输出对象的地址实际是没有什么意义的，开发中更希望输出对象是看对象的内容信息，所以子类需要重写object的tostring方法
        //以便以后输出对象就近调用子类重写的tostring方法返回对象的内容
    }
}
class student extends Object{
    private String name;
    private int age;

    @Override
    public String toString() {
        return "student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    public student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
