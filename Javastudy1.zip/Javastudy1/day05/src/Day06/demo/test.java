package Day06.demo;

import Day06.extends6constructor.consultant;

public class test {
    public static void main(String[] args) {
      //目标：加油站支付小程序
        //1.创建卡片类，一边创建金卡，银卡对象，封装车主数据
        //2.定义一个卡片父类：card，定义金卡和银卡的共同数据和方法
    }
}
