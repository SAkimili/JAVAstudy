package staticDemo;

public class Student {
    private int score;
    public  static void printHelloWorld(){
        System.out.println("Hello");
        System.out.println("Hello");
        System.out.println("Hello");
    }
    //实例方法：没有static修饰，属于对象持有
    public void printPass() {
        System.out.println(score >= 60 ? "这么牛逼，没挂科" : "挂科了，挂科了");
    }
public void setScore(int score){
        this.score=score;
}
    }

