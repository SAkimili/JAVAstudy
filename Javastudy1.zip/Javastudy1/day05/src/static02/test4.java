package static02;
public class test4 {
    //静态变量
    public static int a=10;
    //静态方法
    public static void method(){
        System.out.println("hello");
    }
    //实例变量：属于对象的。
    private String  name;
    //实例方法：属于对象的。
    private void run(){

    }
    public static void main(String[] args) {
        //目标：搞清楚静态方法，实例方法访问的几点注意事项
    }
    //1.静态方法可以直接访问静态成员，静态方法不可以直接访问实例成员
    public static void method1(){
        System.out.println(a);
        method();
        //System.out.println(name);//报错
        //run();//报错
    }
    //2.实例方法既可以直接访问静态成员，也可以访问实例成员
    public void method2(){
        System.out.println(a);
        method();
        System.out.println(name);
        run();
    }
    //3.静态方法不可以通过this访问实例成员，实例方法可以访问实例成员
    //实例方法中可以出现this关键字，静态方法中不可以出现this关键字
    public void go(){
        method();
        System.out.println(a);
        run();
        System.out.println(name);
        System.out.println(this);
    }
}
