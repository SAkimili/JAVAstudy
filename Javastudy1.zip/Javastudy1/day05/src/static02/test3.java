package static02;

public class test3 {
    //目标：搞清楚静态方法的应用：可以做工具类
    //登陆界面
    //开发一个应用程序
    public static void main(String[] args) {
        String code = verifyCodeUtil.getCode(6);
        System.out.println(code);

    }
}
