package static02;
//静态方法设计工具类
public class verifyCodeUtil {
    //工具类没有创建对象的必要性，所以建议私有化构造器
    private verifyCodeUtil() {}
    public static String getCode(int n) {
        //帮我生成一个随机生成验证码的方法
        String code = "";
        for (int i = 0; i < n; i++) {
            int num = (int) (Math.random() * 10);
            code += num;
        }
        return code;
    }
}


