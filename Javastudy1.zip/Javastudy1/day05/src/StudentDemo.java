public class StudentDemo {
    public static void main(String[] args) {
        //目标：创建对象，并访问对象中的属性和方法，搞清楚其特点和常见应用场景
        //构造器的特点：创建对象时，对象会立即自动调用构造器
        Student s1 = new Student();
        //对象的一种常见的应用场景，创建对象时可以立即为对象赋值
        Student s2 = new Student("小明",12,'男');
        s2.age=16;
        s2.name="阿↑姆↓罗";
        System.out.println(s1.name);
        System.out.println(s2.age);
        System.out.println(s2.name);
        Student s3=new Student("AA建材批发");


    }
}
