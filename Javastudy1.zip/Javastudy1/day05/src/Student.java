public class Student {
    String name;
    int age;
    public  Student(){
        //1.无参数构造器
        //构造器：一种特殊的方法，不能写返回值类型，名称必须与类名相同，可以有参数，也可以没有参数
    System.out.println("**无参数构造器**");
    }
    public  Student(String a,int b,char c){
        //2.带参数的构造器
        //构造器：一种特殊的方法，不能写返回值类型，名称必须与类名相同，可以有参数，也可以没有参数
        name=a;
        age=b;
    }
    public Student(String N){
       System.out.println("***带一个参数的构造器***");
    }
}
