public class Pepole {
    String name;
    //1.如何隐藏：使用private关键字（私有，隐藏）修饰成员变量
    //其他任何地方不能直接访问
    private int age;
    private double score;

    //2.如何暴露（合理暴露），使用public修饰（公开）的get和set方法合理暴露
    //成员变量的取值和赋值
    public void setAge(int a) {
        if (a > 0 && a < 150) {
            age = a;
        } else {
            System.out.println("年龄不合法");
        }
    }

    public int getAge() {
        return age;
    }

    public void  printScore() {
        System.out.println("成绩是：" + score);

    }
}
