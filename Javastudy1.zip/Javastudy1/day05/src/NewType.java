public class NewType {
    String name;
    int age;
    int height;
    String sex;
    public NewType() {
        //this是一个变量，用在方法中，用于拿到当前对象
        //那个对象调用这个方法，this就拿到哪个对象
        System.out.println(this);
        System.out.println(this.name);
    }
    public void printHObby(String name) {
        System.out.println(this.name+"喜欢"+name);
    }

}
