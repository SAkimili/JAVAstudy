package javabean;

public class StudentOPerator {
    //必须拿到要处理的学生对象
    private  student s;//用于记住将来要操作的学生对象 null
    public StudentOPerator(student s){
        this.s=s;
    }
    //提供方法，打印学生的总年龄
    public void printAllage( ){

        System.out.println(s.getName()+"的总年龄为："+s.getAge());
    }
}
