package javabean;

public class test {
    public static void main(String[] args) {
//目标：搞清楚实体类是啥，并且知道其基本作用和应用场景
        //实体类得基本作用：创建它的对象，存取数据（封装数据）
        student s1 = new student();
        s1.setName("amorous");
        s1.setAge(18);
        System.out.println(s1.getName());
        System.out.println(s1.getAge());
        student s2 = new student("哈比夏", 19);
        System.out.println(s2.getName());
        System.out.println(s2.getAge());
        //实体类在开发中的应用场景
        //创建一个学生的操作对象专门负责对学生对象的数据进行业务处理
        StudentOPerator oPerator = new StudentOPerator(s2);
        oPerator.printAllage( );

    }
}
