public class PepoleTest {
    public static void main(String[] args) {
        Pepole p1 = new Pepole();
        p1.name = "Armor";
        p1.setAge(15);//赋值
        System.out.println(p1.getAge());//取值
    }
}
