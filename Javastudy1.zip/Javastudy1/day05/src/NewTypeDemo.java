public class NewTypeDemo {
     public static void main(String[] args) {
         System.out.println("----Warning---");
         System.out.println("***NewType***");
         System.out.println("-----------------");
         NewType nt1 = new NewType();
         nt1.name = "阿姆罗·雷";
         nt1.age=16;
         nt1.height=168;
         nt1.sex="男";
         System.out.println("-----------------");
         System.out.println(nt1.name);
         System.out.println(nt1.age);
         System.out.println(nt1.height);
         System.out.println(nt1.sex);
         System.out.println("-----------------");
         NewType nt2 = new NewType();
         nt2.name = "夏亚";
         System.out.println(nt2.name);
         nt2.printHObby("红色");

    }
}
